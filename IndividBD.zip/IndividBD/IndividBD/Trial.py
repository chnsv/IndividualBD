import sqlite3 as sq

class Trial:
    @staticmethod
    def getHotel(self):
        with sq.connect("bd05.db") as con:
            cur = con.cursor()
            cur.execute("SELECT COUNT(*) FROM hotel")
            total_cases = cur.fetchone()[0]
            return f"Общее количество отелей: {total_cases}"
    @staticmethod
    def getPlt(self, hotel_id):
        with sq.connect("bd05.db") as con:
            cur = con.cursor()
            cur.execute("SELECT number FROM rooms WHERE hotel_id = ? AND status = 'Cleaning'", hotel_id)
            plt = cur.fetchone()
            if plt:
                return f"Комната {hotel_id} в режиме: {plt}"
            return f"Комната {hotel_id} не найдена"
    @staticmethod
    def insertHotel(self, data):
        with sq.connect("bd05.db") as con:
            cur = con.cursor()
            cur.execute('''INSERT INTO hotel(name, address) VALUES (?,?)''', data)

    @staticmethod
    def insertRoom_categories(self, data):
        with sq.connect("bd05.db") as con:
            cur = con.cursor()
            cur.execute('''INSERT INTO room_categories (category_name, price) VALUES (?,?)''', data)

    @staticmethod
    def insertRooms(self, data):
        with sq.connect("bd05.db") as con:
            cur = con.cursor()
            cur.execute('''INSERT INTO rooms (hotel_id, category_id, number, status) VALUE (?,?,?)''', data)

    @staticmethod
    def insertServices(self, data):
        with sq.connect("bd05.db") as con:
            cur = con.cursor()
            cur.execute('''INSERT INTO services (service_name, price_s) VALUES (?,?)''', data)