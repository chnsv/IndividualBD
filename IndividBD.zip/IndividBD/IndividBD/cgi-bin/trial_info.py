import cgi
import cgitb
cgitb.enable()
import sqlite3
import xml.etree.ElementTree as xml

con = sqlite3.connect('bd05.db')
cur = con.cursor()
form = cgi.FieldStorage()
name = form.getfirst("Name", "Empty")
address = form.getfirst("address", "Empty")

tree = xml.parse('table.xml')
root = tree.getroot()

hotelEl=xml.SubElement(root,"Hotel")

nameEl = xml.SubElement(hotelEl,"Name")
nameEl.text=name

addressEl = xml.SubElement(hotelEl,"Address")
addressEl.text=address

tree.write('table.xml')

table=root.iter()
arg=[]
for child in root:
    print(child.tag)
    print("<br>")
    if child.tag == "Hotel":
        for step_child in child:
            arg.append(step_child.text)
    sql1 = '''INSERT INTO hotel (name,address) VALUES(?,?)'''
    cur.execute(sql1, arg)
    arg=[]

    con.commit()


print("""
<!DOCTYPE HTML>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <title>Данные отеля</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; padding: 20px; }
        h1 { color: #333; }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .button {
            display: inline-block;
            border-radius: 4px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            padding: 10px 30px;
            margin: 10px 5px;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #45a049;
        }
    </style>
</head>""")

print("""
<body>
<table>
    <h>Таблица из БД</h>
    <tr>
        <th>ID</th>
        <th>Название</th>
        <th>Адрес</th>
    </tr>
""")
cur.execute('SELECT * FROM hotel')
for row in cur.fetchall():
    print(f"""
    <tr> 
        <td>{row[0]}</td>
        <td>{row[1]}</td>
        <td>{row[2]}</td>
    </tr>""")
print("""</table>""")
print("""
</body>
</html>""")





# # Укажите путь к вашей базе данных
# database_path = 'bd05.db'
#
# # Подключение к базе данных
# connection = sqlite3.connect(database_path)
# cursor = connection.cursor()
#
# # Запрос для получения информации о таблицах
# tables_info = {
#     "hotel": "SELECT * FROM hotel;",
#     "room_categories": "SELECT * FROM room_categories;",
#     "rooms": "SELECT * FROM rooms;",
#     "services": "SELECT * FROM services;",
# }
#
# print("Content-Type: text/html")
# print()
#
# # Начало HTML-ответа
#
# # Начало HTML-ответа
# print('<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><title>Форма для добавления отеля</title>')
# print('''<style>
#         body {
#             font-family: Arial, sans-serif;
#             background-color: #f4f4f4;
#             margin: 0;
#             padding: 20px;
#         }
#
#         h1, h2 {
#             color: #333;
#             text-align: center;
#         }
#
#         table {
#             width: 100%;
#             border-collapse: collapse;
#             margin: 20px 0;
#             background-color: white;
#             box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
#         }
#
#         th, td {
#             padding: 12px;
#             text-align: left;
#             border: 1px solid #ddd;
#         }
#
#         th {
#             background-color: #5cb85c;
#             color: white;
#         }
#
#         tr:nth-child(even) {
#             background-color: #f9f9f9;
#         }
#
#         tr:hover {
#             background-color: #f1f1f1;
#         }
#
#         p {
#             text-align: center;
#             color: #666;
#         }
#     </style>''')
# print("</head>")
# print("<body>")
# for table_name, query in tables_info.items():
#     print(f"<h2>Таблица: {table_name}</h2>")
#     cursor.execute(query)
#     rows = cursor.fetchall()
#
#     if rows:
#         print("<table border='1'><tr>")
#         # Вывод заголовков столбцов
#         column_names = [description[0] for description in cursor.description]
#         for column in column_names:
#             print(f"<th>{column}</th>")
#         print("</tr>")
#
#         # Вывод данных
#         for row in rows:
#             print("<tr>")
#             for item in row:
#                 print(f"<td>{item}</td>")
#             print("</tr>")
#         print("</table>")
#     else:
#         print(f"<p>Нет данных в таблице {table_name}.</p>")
#
# # Завершение HTML-ответа
# print("</body></html>")
#
# # Закрытие соединения с базой данных
# connection.close()