import cgi
from IndividBD.Trial import Trial

print("Content-Type: text/html")
print()

print('<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><title>Форма для добавления</title></head>')

form = cgi.FieldStorage()
name = form.getvalue('name')
address = form.getvalue('address')

category_name = form.getvalue('category_name')
price = form.getvalue('price')

hotel_id = form.getvalue('hotel_id')
category_id = form.getvalue('category_id')
number = form.getvalue('location')
status = form.getvalue('status')

price_s = form.getvalue('price')
service_name = form.getvalue('service_name')

if name and address:
    Trial.insertHotel(Trial, [name, address])
    print(f"<h1>Отель {name} добавлен успешно </h1>")
if category_name and price:
    Trial.insertRoom_categories(Trial, [category_name, price])
    print(f"<h1> Номер в категории '{category_name}' с ценой {price} добавлен успешно!")
if hotel_id and category_id and number and status:
    Trial.insertRooms(Trial, [hotel_id, category_id, number, status])
    print(f"<h1> В отеле с id {hotel_id} комната с id {category_id} с номером {number} находится в статусе: {status}</h1>")
if price_s and service_name:
    Trial.insertServices(Trial,[price_s, service_name])
    print(f"<h1>Подключение услуги {service_name} стоит {price_s} </h1>")
print('''
<a href = "/index.html">Вернуться к форме</a>''')