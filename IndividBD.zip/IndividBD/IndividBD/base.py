import sqlite3

#подключение или создание бд
con = sqlite3.connect('bd05.db')
cursor = con.cursor()

cursor.execute('DROP TABLE IF EXISTS hotek')
cursor.execute('''
    CREATE TABLE IF NOT EXISTS hotel(
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        address TEXT NOT NULL
    )
''')
#
# cursor.execute('''
#     CREATE TABLE IF NOT EXISTS room_categories(
#         id INTEGER PRIMARY KEY,
#         category_name TEXT NOT NULL,
#         price INTEGER
#     )
# ''')
#
# cursor.execute('''
#     CREATE TABLE IF NOT EXISTS rooms(
#         id INTEGER PRIMARY KEY,
#         hotel_id INTEGER,
#         category_id INTEGER,
#         number INTEGER,
#         status TEXT NOT NULL,
#         FOREIGN KEY (hotel_id) REFERENCES hotel(id),
#         FOREIGN KEY (category_id) REFERENCES room_categories(id)
#     )
# ''')
#
# cursor.execute('''
#     CREATE TABLE IF NOT EXISTS services(
#         id INTEGER PRIMARY KEY,
#         price_s INTEGER,
#         service_name TEXT NOT NULL
#     )
# ''')

sqlHotel = '''INSERT INTO hotel (name,address) VALUES (?,?)'''
# sqlRoom_categories = '''INSERT INTO room_categories (category_name,price) VALUES (?,?)'''
# sqlRooms = '''INSERT INTO rooms (hotel_id,category_id,number,status) VALUES (?,?,?,?)'''
# sqlServices = '''INSERT INTO services (service_name,price_s) VALUES (?,?)'''
#
varHotel = [('Grand Hotel', '123 Main Street'),
            ('Luxury Inn', '456 Elm Street')]
#
# varRoom_categories = [('Standard Single', '99.99'),
#                       ('Deluxe Double', '149.99'),
#                       ('Suite', '299.99')]
#
# varRooms = [('1', '1', '101', 'Available'),
#     ('1', '2', '102', 'Occupied'),
#     ('1', '3', '103', 'Cleaned'),
#     ('2', '1', '201', 'Available'),
#     ('2', '2', '202', 'Cleaning'),
#     ('2', '3', '205', 'Cleaning')]
#
# varServices = [('Breakfast Buffet', '10.00'),
#     ('Wi-Fi', '5.00'),
#     ('Late Check-out', '20.00')]
#
cursor.executemany(sqlHotel,varHotel)
# cursor.executemany(sqlRoom_categories, varRoom_categories)
# cursor.executemany(sqlRooms, varRooms)
# cursor.executemany(sqlServices, varServices)
# cur = con.cursor()
# cur.execute('''
# SELECT * FROM hotel ''')
# for i in cur.fetchall():
#     print(i)
# cur = con.cursor()
# cur.execute('''
# SELECT * FROM room_categories ''')
# for i in cur.fetchall():
#     print(i)
con.commit()
# con.close()